export default {
    apikey: "ef22e453"
}